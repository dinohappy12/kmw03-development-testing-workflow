# 黃嘉偉KMW03開發測試助手

**測試版｜Plugin 0.1.2｜Skill 0.3.2**

協助把需求整理成小步、檢查實際工具能力、定位問題、節制測試，最後交付白話驗收。先建議適合的模型及思考程度，請使用者依帳號實際選項手動切換。

## 安裝試用

1. [下載完整外掛 ZIP](dist/KMW03-development-testing-0.1.2.zip)。
2. 在 ChatGPT 的「外掛程式」選擇「新增 → 上傳外掛程式封存檔」，選擇下載的 ZIP；依畫面操作並確認儲存。
3. 新對話選用「黃嘉偉KMW03開發測試助手」，輸入：「我要修改一個既有技能，先建議模型，再幫我整理規格與有限測試。」

是否可上傳、儲存、執行程式與讀寫檔案，取決於帳號及當前工具權限。只有真實儲存並回讀後，才能稱帳號安裝完成。本版本尚待新對話、手機及學生帳號實測。新專案可使用手機對話規劃；本機檔案、程式與 GitHub 操作須有對應工具及授權。

## 內容與來源

- 主技能：[SKILL.md](skills/bounded-development/SKILL.md) 與 [啟動設定](skills/bounded-development/agents/openai.yaml)。
- 參考資料、有限測試執行器與複製結構檢查器均放在 skills/bounded-development 內；必要檔案已包含於 ZIP。
- 改編方法參考 [Matt Pocock skills v1.3.1](https://github.com/mattpocock/skills/releases/tag/v1.3.1)，詳見包內來源適配記錄；本版不依賴安裝其工具。
- P019 是老師維護的正式母版；此倉庫與 ZIP 是交付副本。

此倉庫為公開內容。請勿將學生私人資料、金鑰、帳號資訊或工作中產生的測試結果加入。

## 0.1.2 組織版更新
2026-10-30：正式儲存庫已移至 [DinoHappyKM](https://github.com/DinoHappyKM/kmw03-development-testing-workflow)，保留原專案歷史與公開狀態。套件來源網址更新，技能入口與外掛均沿用DinoH正式Logo原圖；測試程式未改。舊版ZIP保留供追溯，請下載上方0.1.2完整包。GitHub移轉不會自動改變帳號內已安裝外掛。

## 0.1.1 更新
- 每步預設最多30秒；需要延長時記錄理由，仍受剩餘總預算限制。
- 工具打不開也會保存當輪錯誤與已用次數；超時先標未完成，不直接判作品有錯。
- 修改測試計畫保留同一state、原預算與案例ID，透過`--revision-reason`保存修改原因。
- 突然中斷不靜默重跑；回報待處理，避免重複執行。

## 可重現驗證
本機使用 Python 3.11 以上執行 `python -m unittest discover -s tests -p "test_*.py" -v`；無須模型API或外部套件。90秒等長設定以替身檢查傳入上限；短超時、找不到程式、連續兩敗及續接使用實際程序或落盤檔案。CI在Windows、Linux與macOS執行相同案例；實際狀態請查看Actions，不能以設定檔存在當成通過。

帳號內既有外掛不會因GitHub更新自動完成升級；請依原安裝入口更新完整ZIP。手機、新對話及帳號安裝需另外驗收。
